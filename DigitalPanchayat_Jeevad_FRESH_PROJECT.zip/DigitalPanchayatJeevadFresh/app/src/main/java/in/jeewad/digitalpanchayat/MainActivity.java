package in.jeewad.digitalpanchayat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, bottom;
    int blue = Color.rgb(5,89,168);
    int dark = Color.rgb(3,68,127);

    String[] names = {"मतदाता खोज", "पंच लेखा-जोखा", "किसान", "शिक्षा", "पंचायत", "जन सेवा केंद्र"};
    String[] icons = {"🗳️", "💰", "🌾", "🏫", "🏛️", "🏢"};
    int[] cardColors = {0xff168BE8,0xffffa51c,0xff25B54B,0xff7B45E6,0xffef3e4d,0xff14A7B5};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }

    TextView tv(String s, float size, int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable bg(int color, float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xfff5f8fb);
        setContentView(root);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),dp(8),dp(12),dp(8)); header.setBackgroundColor(blue);
        TextView menu=tv("☰",34,Color.WHITE); menu.setGravity(Gravity.CENTER); header.addView(menu,lp(dp(54),dp(62)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setGravity(Gravity.CENTER);
        TextView a=tv("DIGITAL PANCHAYAT",24,Color.WHITE); a.setGravity(Gravity.CENTER); a.setTypeface(null,1);
        TextView c=tv("जीवद ग्राम पंचायत",21,Color.WHITE); c.setGravity(Gravity.CENTER); c.setTypeface(null,1); titles.addView(a); titles.addView(c);
        header.addView(titles,lp(0,dp(62),1));
        TextView bell=tv("🔔",27,Color.WHITE); bell.setGravity(Gravity.CENTER); header.addView(bell,lp(dp(54),dp(62)));
        root.addView(header,lp(-1,dp(78)));
        ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(10),dp(12),dp(10)); sc.addView(content); root.addView(sc,lp(-1,0,1));
        bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER); bottom.setBackgroundColor(dark); root.addView(bottom,lp(-1,dp(70)));
    }

    void showHome(){ base();
        TextView hero=tv("डिजिटल पंचायत – विकास की ओर एक कदम\n\n🌾     🏫     🏛️     👩‍🌾     🌱",18,Color.WHITE); hero.setGravity(Gravity.CENTER); hero.setTypeface(null,1); hero.setBackground(bg(0xff1976D2,dp(20))); content.addView(hero,lp(-1,dp(180))); margin(hero,0,0,0,12);
        TextView dots=tv("●  ○  ○  ○  ○",18,0xff168BE8); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(30)));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        for(int r=0;r<3;r++){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); for(int c=0;c<2;c++){ int i=r*2+c; row.addView(card(i),lp(0,dp(142),1)); if(c==0) ((LinearLayout.LayoutParams)row.getChildAt(c).getLayoutParams()).rightMargin=dp(6); } grid.addView(row,lp(-1,dp(148))); }
        content.addView(grid);
        TextView notice=tv("📢   ताजा सूचना\nजीवद ग्राम पंचायत में डिजिटल सेवाओं के माध्यम से आपकी सुविधा के लिए यह ऐप बनाया गया है।",15,0xff15446e); notice.setPadding(dp(16),dp(10),dp(16),dp(10)); notice.setBackground(bg(0xffdff3ff,dp(18))); content.addView(notice,lp(-1,dp(88))); margin(notice,0,8,0,0);
        nav("होम", "सेवाएँ", "सूचनाएँ", "हमारे बारे में");
    }
    View card(final int i){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(dp(12),dp(8),dp(8),dp(8)); box.setBackground(bg(cardColors[i],dp(22))); box.setOnClickListener(v->openModule(i));
        TextView ic=tv(icons[i],34,Color.WHITE); ic.setGravity(Gravity.CENTER); box.addView(ic,lp(dp(55),dp(100)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); TextView n=tv(names[i],20,Color.WHITE); n.setTypeface(null,1); TextView d=tv(desc(i),12,Color.WHITE); d.setMaxLines(3); tx.addView(n); tx.addView(d); box.addView(tx,lp(0,-2,1)); TextView ar=tv("›",34,Color.WHITE); ar.setGravity(Gravity.CENTER); box.addView(ar,lp(dp(30),dp(100))); return box;
    }
    String desc(int i){ String[] d={"नाम, पिता/पति नाम, EPIC या वोटर क्रमांक से खोजें","वित्तीय विवरण, योजनाएँ, खर्च और रिपोर्ट देखें","योजनाएँ, फसल, बीमा, मंडी और अन्य सेवाएँ","स्कूल, शिक्षक, उपस्थिति, परिणाम और जानकारी","सूचना, नोटिस, ग्राम सभा, बैठक और निर्णय","प्रमाण पत्र, आवेदन और ऑनलाइन सेवाएँ"}; return d[i]; }
    void openModule(int i){
        base(); TextView title=tv(icons[i]+"  "+names[i],26,blue); title.setTypeface(null,1); title.setGravity(Gravity.CENTER); content.addView(title,lp(-1,dp(70)));
        TextView info=tv(moduleText(i),17,0xff243746); info.setPadding(dp(20),dp(20),dp(20),dp(20)); info.setBackground(bg(Color.WHITE,dp(18))); content.addView(info,lp(-1,dp(230)));
        Button back=new Button(this); back.setText("← होम पर वापस जाएँ"); back.setOnClickListener(v->showHome()); content.addView(back,lp(-1,dp(58))); nav("होम", "सेवाएँ", "सूचनाएँ", "हमारे बारे में");
    }
    String moduleText(int i){ String[] t={"नाम, पिता/पति नाम, EPIC या वोटर क्रमांक से वार्ड-wise मतदाता खोज।\n\nनोट: वास्तविक मतदाता डेटा अलग से जोड़ा जाएगा।","पंचायत/ग्राम के खातों, प्राप्ति, खर्च, परियोजनाओं और शेष राशि का पारदर्शी रिकॉर्ड।","खाद-बीज सोसाइटी, उपलब्धता, आने वाली सामग्री, वितरण तारीख और किसान सूचनाएँ।","कक्षा 1–12, शिक्षक, उपस्थिति और अभिभावक सूचना के लिए शिक्षा पोर्टल।","पंचायत सूचना, पंचायत के काम, बजट, रिकॉर्ड, फोटो/दस्तावेज और शिकायत/सुझाव।","राशन, सेवा केंद्र समय, जन आधार और Aadhaar डाउनलोड जैसी सेवाओं के लिंक।"}; return t[i]; }
    void nav(String a,String b,String c,String d){ bottom.removeAllViews(); String[] x={"⌂\n"+a,"▦\n"+b,"♧\n"+c,"ⓘ\n"+d}; for(int i=0;i<4;i++){ TextView t=tv(x[i],13,Color.WHITE); t.setGravity(Gravity.CENTER); final int k=i; t.setOnClickListener(v->{ if(k==0) showHome(); else Toast.makeText(this,x[k].replace("\n"," ")+" — जल्द उपलब्ध",Toast.LENGTH_SHORT).show();}); bottom.addView(t,lp(0,dp(68),1)); } }
    void margin(View v,int l,int t,int r,int b){ LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)v.getLayoutParams(); p.setMargins(dp(l),dp(t),dp(r),dp(b)); v.setLayoutParams(p); }
}
