# DIGITAL PANCHAYAT – जीवद ग्राम पंचायत (FRESH)

This is a completely fresh Android project. It does **not** use the previous VOTERS JEEWAD APK/project as its source.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`
- Java 17
- Gradle 8.11.1
- Android Gradle Plugin 8.9.2
- compileSdk 35
- minSdk 23

The workflow builds `app-debug.apk` and uploads it as an artifact.

## Current mobile Home
- मतदाता खोज
- पंच लेखा-जोखा
- किसान
- शिक्षा
- पंचायत
- जन सेवा केंद्र

The Home screen is native Android and responsive to phone width. Backend/data integration can be added module-by-module without replacing the fresh app shell.
